/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Austin
 *
 * Created on October 25, 2022, 9:49 AM
 */

#include <utility>
#include <iostream>
#include <iterator>
#include <list>
#include <set>
#include <algorithm>
#include <cmath>
#include <ctime>

#include "battleship.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    battleship *game = new battleship;
    
    //game->startGame();

    return 0;
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   Node.h
 * Author: Austin
 *
 * Created on December 1, 2022, 8:35 PM
 */

#ifndef NODE_H
#define NODE_H
struct Node  { 
    int data; 
    struct Node *left; 
    struct Node *right; 
}; 

#endif /* NODE_H */


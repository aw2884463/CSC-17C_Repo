/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   ship.h
 * Author: Austin
 *
 * Created on November 5, 2022, 5:25 PM
 */

#ifndef SHIP_H
#define SHIP_H

struct ship {
    int number;
    int size;
    bool *pegs;
    bool sunk;
};

#endif /* SHIP_H */


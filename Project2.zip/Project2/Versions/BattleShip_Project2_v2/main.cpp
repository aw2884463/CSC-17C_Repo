/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Austin
 *
 * Created on October 23, 2022, 7:58 AM
 */


#include <iterator>
#include <list>
#include <iterator>

#include "battleship.h"

using namespace std;

/*
 * 
 */


int main(int argc, char** argv) {
    
    battleship game;

    game.startGame();

    return 0;
}

